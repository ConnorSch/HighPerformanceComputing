#!/bin/bash

echo "Hello from SLURM!"
hostname
echo "Goodbye"

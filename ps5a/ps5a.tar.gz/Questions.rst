

- At what problem size do the answers between the computed norms start to differ?


- How do the absolute and relative errors change as a function of problem size?


- Does the Vector class behave strictly like a member of an abstract vector class?


- Do you have any concerns about this kind of behavior?


